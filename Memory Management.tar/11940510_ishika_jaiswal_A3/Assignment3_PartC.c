// Write a multithreaded program that calculates various statistical values for a list of numbers. This
// program will be passed a series of numbers on the command line and will then create three
// separate worker threads. One thread will determine the average of the numbers, the second will
// determine the maximum value, and the third will determine the minimum value.

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
// INT MAX 
#define INT_MAX 2147483647
// INT MIN
#define INT_MIN -2147483648

int num_threads = 3;
int num_nums = 0;
float avg = 0;
int max = INT_MIN;
int min = INT_MAX;

// calculate the average of the numbers
void *average(void *arg) {
    int sum = 0;
    int i = 0;
    int *numbers = (int *) arg;

    for (i = 0; i < num_nums; i++) {
        sum += numbers[i];
    }

    avg = (float) sum / num_nums;
    printf("Average: %f and the thread id is %lu\n", avg, pthread_self());
    pthread_exit(NULL);
}

// calculate the maximum value of the numbers
void *maximum(void *arg) {
    int i = 0;
    int *numbers = (int *) arg;

    for (i = 0; i < num_nums; i++) {
        if (numbers[i] > max) {
            max = numbers[i];
        }
    }
    
    printf("Maximum: %d and the thread id is %lu\n", max, pthread_self());
    pthread_exit(NULL);
}

// calculate the minimum value of the numbers
void *minimum(void *arg) {
    int i = 0;
    int *numbers = (int *) arg;

    for (i = 0; i < num_nums; i++) {
        if (numbers[i] < min) {
            min = numbers[i];
        }
    }

    printf("Minimum: %d and the thread id is %lu\n", min, pthread_self());
    pthread_exit(NULL);
}

int main() {
    
    // Enter the number of numbers to be calculated
    printf("Enter the number of numbers to be calculated: ");
    scanf("%d", &num_nums);
    // Enter the numbers
    int nums[num_nums];
    printf("Enter the numbers: ");
    int i = 0;
    for (i = 0; i < num_nums; i++) {
        scanf("%d", &nums[i]);
    }
    // print a line
    printf("\n");

    // create threads
    pthread_t *threads = malloc(sizeof(pthread_t) * num_threads);
    // create thread to calculate average
    pthread_create(&threads[0], NULL, average, (void *) nums);
    // create thread to calculate maximum
    pthread_create(&threads[1], NULL, maximum, (void *) nums);
    // create thread to calculate minimum
    pthread_create(&threads[2], NULL, minimum, (void *) nums);

    // wait for threads to finish
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    // print a line 
    printf("\n");
    // print the average and maximum and minimum values of the numbers from the parent with process id 
    printf("Average: %f, Maximum: %d, Minimum: %d and the process id is %lu\n", avg, max, min, (unsigned long) getpid());
    


    // free memory
    free(threads);

    return 0;



}
