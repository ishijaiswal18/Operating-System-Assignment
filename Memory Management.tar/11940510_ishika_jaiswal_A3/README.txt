The codes are provided in the tar file.

For part a, the command to compile is: sudo python3 <filename>.py <process id>
For part b, the command to compile is: sudo python3 <filename>.py <process id> <virtual address>
For part c, the command to compile is: gcc <filename>

make sure that the necessary libraries are installed on your system.

If not, run the following command to install all of the required libraries:
sudo apt-get install build-essentials