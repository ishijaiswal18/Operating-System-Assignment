import os
import sys
import struct
import binascii



if __name__ == "__main__":
    # get the PID as a command-line argument
    PID = int(sys.argv[1])
    # assert the PID is valid and exists in /proc directory and is a process ID (PID) and not a file name (e.g. /proc/1/maps)
    assert PID > 0, "PID must be a positive integer"
    assert os.path.isdir("/proc/" + str(PID)), "PID must be a valid PID"
    # assert the /proc/{pid}/maps file exists
    assert os.path.isfile("/proc/" + str(PID) + "/maps"), "PID must be a valid PID"
    assert os.access("/proc/" + str(PID) + "/maps", os.R_OK), "PID must be a valid PID"
    # assert the /proc/{pid}/pagemap file exists
    assert os.path.isfile("/proc/" + str(PID) + "/pagemap"), "PID must be a valid PID"
    assert os.access("/proc/" + str(PID) + "/pagemap", os.R_OK), "PID must be a valid PID"

    hex_addressess = []
    addresses = []
    # open the file /proc/[pid]/maps
    with open("/proc/{}/maps".format(PID)) as f:
        for line in f:
            line = line.split()
            # store the starting virtual address of the process
            hex_addressess.append(line[0].split('-')[0])
            # convert the starting virtual address to decimal and store it in the list
            addresses.append(int(line[0].split('-')[0], 16))


for address in addresses:
    
    # assert the /proc/{pid}/pagemap file exists
    assert os.path.isfile("/proc/{}/pagemap".format(PID)), "PID must be a valid PID"
    assert os.access("/proc/{}/pagemap".format(PID), os.R_OK), "PID must be a valid PID"
    # open the file /proc/[pid]/pagemap
    # page size
    page_size = os.sysconf("SC_PAGE_SIZE")
    # pagemap entry size 
    pagemap_entry_size = 8
    # calculate the offset of the starting virtual address in the pagemap file
    offset = (address // page_size) * pagemap_entry_size
    # pagemap entry
    pagemap_entry = -1
    with open("/proc/{}/pagemap".format(PID), "rb") as f:
        # seek to the offset
        f.seek(offset)
        pagemap_entry = struct.unpack("Q", f.read(pagemap_entry_size))[0]

    # page frame number
    page_frame_number = pagemap_entry & ((1 << 55) - 1)
    # print the page frame number
    print("page frame number : " , page_frame_number)
    # print the starting virtual address
    print("virtual address : ", hex(address))
            