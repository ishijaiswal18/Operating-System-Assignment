import os
import sys
import struct
import binascii



if __name__ == "__main__":
    # get the PID as a command-line argument
    PID = int(sys.argv[1])
    # get the starting virtual address as a command-line argument
    start_address = sys.argv[2]
    # assert the PID is valid and exists in /proc directory and is a process ID (PID) and not a file name (e.g. /proc/1/maps)
    assert PID > 0, "PID must be a positive integer"
    assert os.path.isdir("/proc/" + str(PID)), "PID must be a valid PID"
    # assert the /proc/{pid}/maps file exists
    assert os.path.isfile("/proc/" + str(PID) + "/maps"), "PID must be a valid PID"
    assert os.access("/proc/" + str(PID) + "/maps", os.R_OK), "PID must be a valid PID"
    # assert the /proc/{pid}/pagemap file exists
    assert os.path.isfile("/proc/" + str(PID) + "/pagemap"), "PID must be a valid PID"
    assert os.access("/proc/" + str(PID) + "/pagemap", os.R_OK), "PID must be a valid PID"

    # hex_addressess = []
    # addresses = []
    # # open the file /proc/[pid]/maps
    # with open("/proc/{}/maps".format(PID)) as f:
    #     for line in f:
    #         line = line.split()
    #         # store the starting virtual address of the process
    #         hex_addressess.append(line[0].split('-')[0])
    #         # convert the starting virtual address to decimal and store it in the list
    #         addresses.append(int(line[0].split('-')[0], 16))

    # convert start_address to to decimal
    address = int(start_address, 16)

    
# print the starting virtual address of every process in the list

# for address in addresses:
    
# assert the /proc/{pid}/pagemap file exists
assert os.path.isfile("/proc/{}/pagemap".format(PID)), "PID must be a valid PID"
assert os.access("/proc/{}/pagemap".format(PID), os.R_OK), "PID must be a valid PID"
# open the file /proc/[pid]/pagemap
# page size
page_size = os.sysconf("SC_PAGE_SIZE")
# pagemap entry size 
pagemap_entry_size = 8
# calculate the offset of the starting virtual address in the pagemap file
offset = (address // page_size) * pagemap_entry_size
# pagemap entry
pagemap_entry = 0
with open("/proc/{}/pagemap".format(PID), "rb") as f:
    # seek to the offset
    f.seek(offset)
    
    pagemap_entry = struct.unpack("Q", f.read(pagemap_entry_size))[0]

# page frame number (Bits 0-54)
page_frame_number = pagemap_entry & ((1 << 55) - 1)
# get the swap type (Bits 0-4)
swap_type = pagemap_entry & ((1 << 5) - 1) # 
# get the swap offset (Bits 5-54)
swap_offset = pagemap_entry >> 55 & ((1 << 6) - 1)
# get the pte soft dirtiness (Bit 55)
pte_soft_dirtiness = pagemap_entry >> 55 & 1
# get the page exclusively mapped (Bit 56)
page_exclusively_mapped = pagemap_entry >> 56 & 1
# get the zero page (Bit 57-60)
zero_page = pagemap_entry >> 57 & ((1 << 4) - 1)
# get the page file-page or shared anon (Bit 61)
page_file_page_or_shared_anon = pagemap_entry >> 61 & 1
# het the page swapped (Bit 62)
page_swapped = pagemap_entry >> 62 & 1
# get the page present (Bit 63)
page_present = pagemap_entry >> 63 & 1
# translate the page frame number and virtual address to physical address
physical_address = page_frame_number * page_size + address % page_size
# print the starting virtual address
print("starting virtual address : ", hex(address))
# print the starting physical address
print("starting physical address : ", hex(physical_address))
# print pagemap entry
print("pagemap entry : ", hex(pagemap_entry))
# print the page frame number
print("page frame number : " , page_frame_number)
# print the swap type
print("swap type : ", swap_type)
# print the swap offset
print("swap offset : ", swap_offset)
# print the pte soft dirtiness
print("pte soft dirtiness : ", pte_soft_dirtiness)
# print the page exclusively mapped
print("page exclusively mapped : ", page_exclusively_mapped)
# print the zero page
print("zero page : ", zero_page)
# print the page file-page or shared anon
print("page file-page or shared anon : ", page_file_page_or_shared_anon)
# print the page swapped
print("page swapped : ", page_swapped)
# print the page present
print("page present : ", page_present)
# print a new line
print()
# print a line 
print("----------------------------------------------------------------------------------------------------------------------")
# print a new line
print()    


    
            