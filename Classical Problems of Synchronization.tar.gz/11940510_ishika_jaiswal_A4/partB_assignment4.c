#include <stdio.h>    
#include <unistd.h>    
#include <errno.h>     //Including for macros intialisation
#include <pthread.h>   //Using access of threads
#include <semaphore.h> //Using Syncronisation of threads


// A process can create
// two threads which have access to the common variable count whose initial value is 0. One thread
// will increment it till it reaches 20 and other thread should read each of the incremented value
// and print the value with the thread id.

int cnt = 0;
sem_t sem_increment, sem_read;

void *read_fun(void *arg)
{
      while (cnt <= 19)
      {     
       	//This function basically decrements the symaphore pointed to by sem
            sem_wait(&sem_read);
            
            printf("Count : %d, Thread ID : %ld\n\n", cnt, pthread_self());
            
       	//This function basically increments the symaphore pointed to by sem
            sem_post(&sem_increment);
      }
}

void *increment_fun(void *arg)
{
      while (cnt <= 19)
      {     
       	 //This function basically decrements the symaphore pointed to by sem
            sem_wait(&sem_increment);


            //Increment the count variable to 1
            cnt += 1;
            
            
            printf("Count : %d, Thread ID : %ld\n", cnt, pthread_self());
            
            //This function basically increments the symaphore pointed to by sem
            sem_post(&sem_read);
      }
}

int main(){
    //Creating the thread
    pthread_t T[2];

    //here this initialises a symaphore which is unknown and sets the required value
    sem_init(&sem_increment , 0, 1);
    sem_init(&sem_read, 0, 0);

    //This pthread-create function basically creates a thread
    pthread_create(&T[0], NULL, increment_fun, NULL);
    pthread_create(&T[1], NULL, read_fun, NULL);

    //This function basically waits for the thread to terminate
    for (int i = 0; i < 2; ++i)
    {
        pthread_join(T[i], NULL);
    }

    // This function is used to destroy the semaphore
    sem_destroy(&sem_increment);
    sem_destroy(&sem_read);

    return 0;

}


