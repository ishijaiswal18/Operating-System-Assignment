
//  producer consumer problem
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
// include time
#include <time.h>

//  shared variable to store the number of items in the buffer
int cnt = 0;
int TOTAL_ITEMS = 10000;
int size = 0;
int read_ptr = 0;
int write_ptr = 0;
// buffer size
int BUFFER_SIZE = 100;
//  shared variable to store the buffer
int *buffer;
// mutex to control access to the shared variable
pthread_mutex_t mutex;
pthread_mutex_t mutex2;
// condition variable to signal the producer thread
pthread_cond_t cond_nonempty;
// condition variable to signal the consumer thread
pthread_cond_t cond_nonfull;

void *producer_thread(){
    // increase the size by 1
    while (1) {
        // write for 10 milliseconds
        pthread_mutex_lock(&mutex);
        // note the time
        struct timespec start, end;
        clock_gettime(CLOCK_REALTIME, &start);
        printf("Producer thread: ");
        while (1){
            if (size < BUFFER_SIZE) {
                // acquire the mutex
                // fill the buffer
                cnt++;
                if (cnt == TOTAL_ITEMS) {
                    // release the mutex
                    pthread_mutex_unlock(&mutex);
                    // exit the thread
                    pthread_exit(NULL);
                }
                buffer[write_ptr] = cnt;
                // increase the size by 1
                size++;
                printf("%d \n", cnt);
                // increase the write_ptr by 1
                write_ptr = (write_ptr + 1) % BUFFER_SIZE;
                // signal the consumer thread
                pthread_cond_signal(&cond_nonempty);
            }
            else{
                printf("Buffer is full %d \n", size);
                // wait for the condition variable
                pthread_cond_wait(&cond_nonfull, &mutex);
                // orint 
                printf("Producer thread continue: ");
                if (cnt == TOTAL_ITEMS) {
                    // release the mutex
                    pthread_mutex_unlock(&mutex);
                    // exit the thread
                    pthread_exit(NULL);
                } 
            }
            // note the time
            clock_gettime(CLOCK_REALTIME, &end);
            // calculate the time difference
            long diff = (end.tv_sec - start.tv_sec) * 1000000000 + (end.tv_nsec - start.tv_nsec);
            // if the time difference is greater than 10 milliseconds
            if (diff > 10000000) {
                // break the loop
                break;
            }
        }
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

void *consumer_thread(){
    // decrease the size by 1
    while (1) {
        // acquire the mutex
        pthread_mutex_lock(&mutex);
        if (size == 0) {
            printf("Buffer is empty %d \n", size);
            // wait for the condition variable
            pthread_cond_wait(&cond_nonempty, &mutex);
            if (cnt == TOTAL_ITEMS && size == 0) {
                    // release the mutex
                    pthread_mutex_unlock(&mutex);
                    // exit the thread
                    pthread_exit(NULL);
                }
            printf("Consumer thread continue: ");
            
        }
        printf("Consumer thread : ");
        while(size > 0) {
                
                printf("%d \n", buffer[read_ptr]);
                // consume the buffer
                buffer[read_ptr] = 0;
                // decrease the size by 1
                size--;
                if (cnt == TOTAL_ITEMS && size == 0) {
                    // release the mutex
                    pthread_mutex_unlock(&mutex);
                    // exit the thread
                    pthread_exit(NULL);
                }
                
                // increase the read_ptr by 1
                read_ptr = (read_ptr + 1) % BUFFER_SIZE;

                // signal the condition variable
                pthread_cond_signal(&cond_nonfull);
        }
        // print a new line 
        printf("\n");
        pthread_mutex_unlock(&mutex);

    }

    return NULL;
}


int main(){

    //  initialize the mutex
    pthread_mutex_init(&mutex, NULL);
    pthread_mutex_init(&mutex2, NULL);
    //  initialize the condition variable
    pthread_cond_init(&cond_nonempty, NULL);
    pthread_cond_init(&cond_nonfull, NULL);


    //  initialize the buffer
    buffer = (int *)malloc(sizeof(int)*BUFFER_SIZE);

    //  create the producer thread
    pthread_t producer;
    pthread_create(&producer, NULL, producer_thread, NULL);

    //  create the consumer thread
    pthread_t consumer;
    pthread_create(&consumer, NULL, consumer_thread, NULL);

    //  wait for the producer thread to finish
    pthread_join(producer, NULL);

    //  wait for the consumer thread to finish
    pthread_join(consumer, NULL);

    //  destroy the mutex
    pthread_mutex_destroy(&mutex);

    return 0;

}