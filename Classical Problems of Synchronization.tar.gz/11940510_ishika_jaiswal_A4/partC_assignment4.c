// reader writer problem
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <semaphore.h>

// When a reader thread has gained access to the shared variable then writer should wait and vice versa. There can
// be any number of readers reading the shared variable at the same time. At most only one writer
// should be allowed to write the shared variable at once. Solve this problem using semaphores and
// shared variables.

sem_t reader_smph, writers_smph;
pthread_t w_thread[2], r_thread[5];

int readers_cnt = 0;
int writers_cnt = 0;
int shared = 9;
int MAX_ITEMS = 1000;
int active = 0;
// int temp = 0;
int r_id = 0;

void *writer_thread(void *arg){
    int *ids = (int *)arg;
    int id = ids[0];

    while(1) {
    // writer requests for critical section
    if (shared >= MAX_ITEMS) {
        pthread_exit(NULL);
    }
    sem_wait(&writers_smph);
   
    // performs the write
    shared = shared + 1;
    printf("\nWriter %d is writing %d \n", id, shared);

    // leaves the critical section
    printf("writer %d is leaving critical section and waiting for 10 milliseconds \n", id);
    sem_post(&writers_smph);
    
    sleep(0.01);

    } 
    return NULL;
}

void *reader_thread(void *arg)
{
    int *ids = (int *)arg;
    int id = ids[0];
    while(1){
    if (shared >= MAX_ITEMS) {
        pthread_exit(NULL);
    }
    // Reader wants to enter the critical section
    sem_wait(&reader_smph);

    // The number of readers has now increased by 1
    readers_cnt++;                          

    // there is atleast one reader in the critical section
    // this ensure no writer can enter if there is even one reader
    // thus we give preference to readers here
    if (readers_cnt==1){
        sem_wait(&writers_smph);
    }

    // other readers can enter while this current reader is inside 
    // the critical section
    sem_post(&reader_smph); 


    // critical section
    printf("\nReader %d is reading %d", id,  shared);
    

    // current reader performs reading here
    sem_wait(&reader_smph);
       // a reader wants to leave

    readers_cnt--;

    // that is, no reader is left in the critical section,
    if (readers_cnt == 0)
        sem_post(&writers_smph); // writers can enter
    printf("\nReader %d is leaving critical section and waiting for 10 milliseconds \n", id);
    sem_post(&reader_smph); // reader leaves
    
    sleep(0.01);
    } 
    return NULL;
}

int main(){

    // initialize the semaphores
    sem_init(&reader_smph, 0, 1);
    sem_init(&writers_smph, 0, 1);

    // buffer
    // buffer = (int *)malloc(sizeof(int)*BUFFER_SIZE);

    // create threads for writer and reader
    
    for (int i = 0; i < 2; i++)
    {
        int *ids = (int *)malloc(sizeof(int)*1);
        ids[0] = i;
        pthread_create(&w_thread[i], NULL, writer_thread, ids);
    }
    
    for (int i = 0; i < 5; i++) {
        int *arg = malloc(sizeof(*arg));
        *arg = i;
        pthread_create(&r_thread[i], NULL, reader_thread, arg);
    }

    // join the threads
    for (int i = 0; i < 2; i++) {
        pthread_join(w_thread[i], NULL);
    }
    for (int i = 0; i < 5; i++) {
        pthread_join(r_thread[i], NULL);
    }

    sem_destroy(&reader_smph);
    sem_destroy(&writers_smph);

    return 0;
}
